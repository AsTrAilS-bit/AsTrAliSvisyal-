package com.antralis;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.particle.ParticleTypes;

public class AnTrAliSMod implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        MinecraftClient client = MinecraftClient.getInstance();
        
        // Устанавливаем максимальную яркость (гамму)
        GameOptions options = client.options;
        options.gamma = 100.0; 

        // Добавляем авто-спринт и визуальные эффекты
        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            PlayerEntity player = client.player;
            if (player != null) {
                if (player.forwardSpeed > 0) {
                    player.setSprinting(true);
                    spawnWalkParticles(player);
                }
                if (player.getAttackCooldownProgress(0.5f) == 1.0f) {
                    spawnHitParticles(player);
                }
            }
        });
    }

    private void spawnWalkParticles(PlayerEntity player) {
        Vec3d pos = player.getPos();
        player.world.addParticle(
            ParticleTypes.FLAME, pos.x, pos.y, pos.z,
            0, 0.02, 0
        );
    }

    private void spawnHitParticles(PlayerEntity player) {
        Vec3d pos = player.getPos().add(0, 1, 0);
        for (int i = 0; i < 5; i++) {
            player.world.addParticle(
                ParticleTypes.CRIT, pos.x, pos.y, pos.z,
                (Math.random() - 0.5) * 0.2, 
                Math.random() * 0.2, 
                (Math.random() - 0.5) * 0.2
            );
        }
    }
}